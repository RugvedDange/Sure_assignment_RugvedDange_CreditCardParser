"use client"

import { useMemo, useState } from "react"
import CSVUploader from "@/components/csv-uploader"
import CreditCardPreview from "@/components/credit-card-preview"
import ReadOnlyCardForm from "@/components/read-only-card-form"

type Row = Record<string, string>

function pickHeader(headers: string[], candidates: string[]) {
  const lower = headers.map((h) => h.toLowerCase())
  for (const c of candidates) {
    const idx = lower.findIndex((h) => h === c || h.includes(c))
    if (idx !== -1) return headers[idx]
  }
  return ""
}

function detectMapping(headers: string[]): any {
  return {
    name: pickHeader(headers, [
      "cardholder name",
      "cardholder",
      "name",
      "card name",
      "holder",
      "full name",
      "card_holder",
    ]),
    number: pickHeader(headers, ["card number", "cardnumber", "number", "cc", "cc_number", "card_no", "pan"]),
    expiry: pickHeader(headers, ["expiry", "expiration", "exp", "exp_date", "expdate", "valid thru", "valid_thru"]),
    expiryMonth: pickHeader(headers, ["exp_month", "expiry_month", "month", "mm"]),
    expiryYear: pickHeader(headers, ["exp_year", "expiry_year", "year", "yy", "yyyy"]),
    cvv: pickHeader(headers, ["cvv", "cvc", "cv2", "security code", "security_code"]),
    last4: pickHeader(headers, ["last4", "last 4", "last_digits", "last_digits4", "ending", "ends_with", "suffix"]),
    totalDue: pickHeader(headers, [
      "total due",
      "amount due",
      "total_due",
      "amount_due",
      "due",
      "total",
      "bill amount",
      "bill",
      "statement amount",
      "statement_total",
    ]),
    remaining: pickHeader(headers, [
      "remaining",
      "due remaining",
      "remaining_due",
      "outstanding",
      "outstanding_balance",
      "balance",
      "balance_due",
    ]),
  }
}

function formatCardNumber(raw: string) {
  const digits = (raw || "").replace(/\D/g, "").slice(0, 19)
  return digits.replace(/(\d{4})(?=\d)/g, "$1 ")
}

function formatExpiryFromParts(mm?: string, yy?: string) {
  const m = (mm || "").replace(/\D/g, "").slice(0, 2)
  let y = (yy || "").replace(/\D/g, "")
  if (y.length === 4) y = y.slice(2)
  y = y.slice(0, 2)
  if (!m && !y) return ""
  return `${m.padStart(2, "0")}/${y.padStart(2, "0")}`
}

function extractLast4FromNumber(raw: string) {
  const digits = (raw || "").replace(/\D/g, "")
  return digits.slice(-4)
}

function formatAmount(raw?: string) {
  const val = (raw || "").toString().trim()
  if (!val) return ""
  const normalized = val.replace(/[^0-9.-]/g, "")
  const num = Number(normalized)
  if (Number.isFinite(num)) {
    try {
      return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(num)
    } catch {
      return num.toLocaleString()
    }
  }
  return val
}

export default function Page() {
  const [headers, setHeaders] = useState<string[]>([])
  const [rows, setRows] = useState<Row[]>([])
  const [selectedRowIndex, setSelectedRowIndex] = useState(0)

  const selectedRow = rows[selectedRowIndex] || {}

  const autoMapping = useMemo(
    () =>
      headers.length
        ? detectMapping(headers)
        : {
            name: "",
            number: "",
            expiry: "",
            expiryMonth: "",
            expiryYear: "",
            cvv: "",
            last4: "",
            totalDue: "",
            remaining: "",
          },
    [headers],
  )

  const values = useMemo(() => {
    const name = selectedRow[autoMapping.name || ""] || ""
    const number = selectedRow[autoMapping.number || ""] || ""
    const cvv = selectedRow[autoMapping.cvv || ""] || ""
    let expiry = selectedRow[autoMapping.expiry || ""] || ""

    if (!expiry) {
      const mm = selectedRow[autoMapping.expiryMonth || ""]
      const yy = selectedRow[autoMapping.expiryYear || ""]
      expiry = formatExpiryFromParts(mm, yy)
    }

    let last4 = (selectedRow[autoMapping.last4 || ""] || "").toString()
    if (!last4) {
      last4 = extractLast4FromNumber(number)
    } else {
      last4 = last4.replace(/\D/g, "").slice(-4)
    }

    const totalDueRaw = selectedRow[autoMapping.totalDue || ""] || ""
    const remainingRaw = selectedRow[autoMapping.remaining || ""] || ""
    const totalDue = formatAmount(totalDueRaw)
    const remaining = formatAmount(remainingRaw)

    const usedKeys = new Set(
      [
        autoMapping.name,
        autoMapping.number,
        autoMapping.cvv,
        autoMapping.expiry,
        autoMapping.expiryMonth,
        autoMapping.expiryYear,
        autoMapping.last4,
        autoMapping.totalDue,
        autoMapping.remaining,
      ].filter(Boolean),
    )

    const extras = Object.entries(selectedRow)
      .filter(([k, v]) => !!v && !usedKeys.has(k))
      .map(([label, value]) => ({ label, value: String(value) }))

    return {
      name: name.trim(),
      number: formatCardNumber(number),
      expiry: (expiry || "").trim(),
      cvv: (cvv || "").replace(/\D/g, "").slice(0, 4),
      last4,
      totalDue,
      remaining,
      extras,
    }
  }, [selectedRow, autoMapping])

  function handleParsed(nextHeaders: string[], nextRows: Row[]) {
    setHeaders(nextHeaders)
    setRows(nextRows)
    setSelectedRowIndex(0)
  }

  return (
    <main className="min-h-dvh w-full px-4 py-8 md:px-6">
      <div className="mx-auto max-w-4xl space-y-6">
        <header className="space-y-2">
          <h1 className="text-pretty text-2xl font-semibold">CSV to Credit Card Viewer</h1>
          <p className="text-sm text-muted-foreground">
            Upload a CSV and we&apos;ll automatically detect columns and render each row on a credit card.
          </p>
        </header>

        <CSVUploader onParsed={handleParsed} />

        {headers.length > 0 && rows.length > 0 && (
          <section className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="bg-card border border-border rounded-lg p-4">
                <div className="grid gap-3">
                  <div className="grid gap-1.5">
                    <label htmlFor="row" className="block text-sm">
                      Select row
                    </label>
                    <select
                      id="row"
                      className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      value={selectedRowIndex}
                      onChange={(e) => setSelectedRowIndex(Number(e.target.value))}
                    >
                      {rows.map((_, i) => (
                        <option key={i} value={i}>
                          Row {i + 1}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <h2 className="text-sm font-medium mb-3">Card Preview</h2>
                    <CreditCardPreview
                      name={values.name || "CARDHOLDER NAME"}
                      number={values.number || "•••• •••• •••• ••••"}
                      expiry={values.expiry || "MM/YY"}
                      cvv={values.cvv || "•••"}
                      last4={values.last4}
                      totalDue={values.totalDue}
                      remaining={values.remaining}
                      extras={values.extras}
                    />
                  </div>
                </div>
              </div>

              <div className="bg-card border border-border rounded-lg p-4">
                <h2 className="text-sm font-medium mb-3">Credit Card Form (Read-only)</h2>
                <ReadOnlyCardForm name={values.name} number={values.number} expiry={values.expiry} cvv={values.cvv} />
                <p className="mt-3 text-xs text-muted-foreground">
                  Values are auto-detected from your CSV columns—no manual mapping required.
                </p>
              </div>
            </div>
          </section>
        )}
      </div>
    </main>
  )
}
