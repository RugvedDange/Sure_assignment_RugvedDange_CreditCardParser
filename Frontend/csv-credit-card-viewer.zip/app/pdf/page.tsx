"use client"
import { PDFUploadAndCardView } from "@/components/pdf-upload-and-card-view"

export default function PdfPage() {
  return (
    <main className="min-h-dvh flex flex-col items-center justify-start p-6 gap-6">
      <header className="w-full max-w-3xl">
        <h1 className="text-2xl font-semibold text-pretty">PDF to Card Viewer</h1>
        <p className="text-sm opacity-80">
          Upload a credit card statement PDF, extract details, download CSV, and preview them on a card.
        </p>
      </header>
      <section className="w-full max-w-3xl">
        <PDFUploadAndCardView />
      </section>
    </main>
  )
}
