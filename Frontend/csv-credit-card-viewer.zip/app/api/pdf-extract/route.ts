import { NextResponse } from "next/server"
import pdf from "pdf-parse"

const PATTERNS: Record<string, RegExp> = {
  Name: /Name\s*[:-]?\s*([A-Z\s]+)/i,
  Email: /Email\s*[:-]?\s*([\w.-]+@[\w.-]+)/i,
  Address: /Address\s*[:-]?\s*(.+)/i,
  "Statement Date": /Statement\s*Date\s*[:-]?\s*([\d/]+)/i,
  "Card Last 4 Digits": /(?:Card No|XXXX)\D*(\d{4})/i,
  "Payment Due Date": /Payment\s*Due\s*Date\s*[:-]?\s*([\d/]+)/i,
  "Total Dues": /Total\s*Amount\s*Due\s*[:-]?\s*(₹?\s?[\d,]+\.\d{2})/i,
  "Minimum Amount Due": /Minimum\s*Amount\s*Due\s*[:-]?\s*(₹?\s?[\d,]+\.\d{2})/i,
  "Credit Limit": /Credit\s*Limit\s*[:-]?\s*([\d,]+)/i,
  "Available Credit Limit": /Available\s*Credit\s*Limit\s*[:-]?\s*([\d,]+)/i,
}

function extractFields(text: string) {
  const data: Record<string, string | null> = {}
  for (const [field, pattern] of Object.entries(PATTERNS)) {
    const match = text.match(pattern)
    data[field] = match?.[1]?.trim() ?? null
  }
  return data
}

export async function POST(request: Request) {
  try {
    const form = await request.formData()
    const file = form.get("file") as File | null

    if (!file) {
      return new NextResponse("Missing file", { status: 400 })
    }
    if (file.type !== "application/pdf") {
      return new NextResponse("File must be a PDF", { status: 400 })
    }

    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Extract using pdf-parse (text-based PDFs)
    const parsed = await pdf(buffer)
    const text = (parsed?.text || "").trim()

    // Derive fields
    const fields = extractFields(text)
    fields["File Name"] = file.name

    return NextResponse.json({ fields, text })
  } catch (err: any) {
    return new NextResponse(err?.message || "Failed to extract PDF", { status: 500 })
  }
}
