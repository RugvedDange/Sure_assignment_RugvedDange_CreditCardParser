"use client"

export type ExtractedFields = Record<string, string | null>

// Ported patterns from the provided Python script
const PATTERNS: Record<string, RegExp> = {
  Name: /Name\s*[:-]?\s*([A-Z\s]+)/i,
  Email: /Email\s*[:-]?\s*([\w.-]+@[\w.-]+)/i,
  Address: /Address\s*[:-]?\s*(.+)/i,
  "Statement Date": /Statement\s*Date\s*[:-]?\s*([\d/]+)/i,
  "Card Last 4 Digits": /(?:Card No|XXXX)\D*(\d{4})/i,
  "Payment Due Date": /Payment\s*Due\s*Date\s*[:-]?\s*([\d/]+)/i,
  "Total Dues": /Total\s*Amount\s*Due\s*[:-]?\s*(?:₹?\s?)([\d,]+\.\d{2})/i,
  "Minimum Amount Due": /Minimum\s*Amount\s*Due\s*[:-]?\s*(?:₹?\s?)([\d,]+\.\d{2})/i,
  "Credit Limit": /Credit\s*Limit\s*[:-]?\s*([\d,]+)/i,
  "Available Credit Limit": /Available\s*Credit\s*Limit\s*[:-]?\s*([\d,]+)/i,
}

// Lazy load pdfjs to avoid SSR issues
async function getPdfJs() {
  // Using legacy build to improve compatibility in bundlers
  const pdfjsLib: any = await import("pdfjs-dist/legacy/build/pdf")
  const worker: any = await import("pdfjs-dist/legacy/build/pdf.worker.min.mjs")
  // @ts-expect-error - type provided by pdfjs at runtime
  pdfjsLib.GlobalWorkerOptions.workerSrc = worker
  return pdfjsLib
}

export async function extractTextFromPdfFile(file: File): Promise<string> {
  const pdfjsLib = await getPdfJs()
  const buffer = await file.arrayBuffer()
  const loadingTask = pdfjsLib.getDocument({ data: buffer })
  const pdf = await loadingTask.promise
  let text = ""

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i)
    const content = await page.getTextContent()
    const strings = content.items.map((it: any) => it.str).join(" ")
    text += strings + "\n"
  }
  return text
}

export function extractFieldsFromText(text: string): ExtractedFields {
  const data: ExtractedFields = {}
  for (const [field, re] of Object.entries(PATTERNS)) {
    const m = text.match(re)
    data[field] = m?.[1]?.trim() ?? null
  }
  return data
}

export async function extractFieldsFromPdfFile(file: File): Promise<ExtractedFields> {
  const text = await extractTextFromPdfFile(file)

  // If nothing extracted (e.g., scanned PDF), we could add an optional Tesseract.js fallback here.
  // For now, return the regex-based fields from extracted text.
  const fields = extractFieldsFromText(text)
  // Attach file name for reference
  fields["File Name"] = file.name
  return fields
}
