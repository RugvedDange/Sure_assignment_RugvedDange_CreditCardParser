"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CardContent } from "@/components/ui/card"
import { CardTitle } from "@/components/ui/card"
import { CardHeader } from "@/components/ui/card"
import { Card } from "@/components/ui/card"
import type React from "react"
import { useMemo, useState } from "react"
import { CreditCardDisplay } from "@/components/credit-card-display"

// Small utility to build a CSV from key/value pairs
function buildCsv(data: ExtractedFields) {
  const headers = Object.keys(data)
  const values = headers.map((k) => (data[k] ?? "").toString().replace(/"/g, '""'))
  const csv = [headers.join(","), values.map((v) => `"${v}"`).join(",")].join("\n")
  return csv
}

type ExtractedFields = Record<string, string | null>

export function PDFUploadAndCardView() {
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<ExtractedFields | null>(null)

  const csvUrl = useMemo(() => {
    if (!result) return null
    const csv = buildCsv(result)
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    return URL.createObjectURL(blob)
  }, [result])

  async function onSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]
    if (!f) return
    setFile(f)
    setResult(null)
    setError(null)
  }

  async function onProcess() {
    if (!file) return
    setLoading(true)
    setError(null)
    try {
      const fd = new FormData()
      fd.append("file", file)
      const res = await fetch("/api/pdf-extract", { method: "POST", body: fd })
      if (!res.ok) {
        const msg = await res.text().catch(() => "Failed to process PDF")
        throw new Error(msg || "Failed to process PDF")
      }
      const { fields } = (await res.json()) as { fields: ExtractedFields }
      setResult(fields)
    } catch (err: any) {
      setError(err?.message || "Failed to process PDF")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Upload PDF</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <div className="grid gap-2">
            <Label htmlFor="pdf">Select a PDF file</Label>
            <Input id="pdf" type="file" accept=".pdf" onChange={onSelect} />
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={onProcess} disabled={!file || loading}>
              {loading ? "Processing…" : "Extract & Preview"}
            </Button>
            {csvUrl && (
              <a href={csvUrl} download="parsed_credit_statement.csv" className="text-primary underline text-sm">
                Download CSV
              </a>
            )}
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Card Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <CreditCardDisplay data={result} />
          </CardContent>
        </Card>
      )}
    </div>
  )
}
