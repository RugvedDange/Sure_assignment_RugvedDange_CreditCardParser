"use client"

export default function CreditCardPreview({
  name,
  number,
  expiry,
  cvv,
  last4,
  totalDue,
  remaining,
  extras = [],
}: {
  name: string
  number: string
  expiry: string
  cvv: string
  last4?: string
  totalDue?: string
  remaining?: string
  extras?: Array<{ label: string; value: string }>
}) {
  return (
    <div
      aria-label="Credit card preview"
      className="relative w-full rounded-xl border border-border bg-primary text-primary-foreground p-4 shadow-sm"
    >
      <div className="flex items-center justify-between text-xs opacity-90">
        <span>V0 Card</span>
        <span>VISA</span>
      </div>

      <div className="mt-6 space-y-4">
        <div className="text-lg tracking-widest">{number || "•••• •••• •••• ••••"}</div>

        {last4 ? (
          <div className="text-xs opacity-90">
            Last 4: <span className="font-medium">{last4}</span>
          </div>
        ) : null}

        <div className="flex items-center justify-between text-sm">
          <div>
            <div className="opacity-80 text-xs">Cardholder</div>
            <div className="font-medium">{name || "CARDHOLDER NAME"}</div>
          </div>
          <div className="text-right">
            <div className="opacity-80 text-xs">Expires</div>
            <div className="font-medium">{expiry || "MM/YY"}</div>
          </div>
        </div>

        <div className="text-right text-xs opacity-80">CVV: {cvv ? "•••" : "•••"}</div>

        {totalDue || remaining ? (
          <div className="mt-2 grid grid-cols-2 gap-3 text-sm">
            {totalDue ? (
              <div className="rounded-md bg-primary/20 px-3 py-2">
                <div className="opacity-80 text-xs">Total Due</div>
                <div className="font-semibold">{totalDue}</div>
              </div>
            ) : null}
            {remaining ? (
              <div className="rounded-md bg-primary/20 px-3 py-2">
                <div className="opacity-80 text-xs">Remaining</div>
                <div className="font-semibold">{remaining}</div>
              </div>
            ) : null}
          </div>
        ) : null}

        {extras && extras.length > 0 ? (
          <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
            {extras.map((item, idx) => (
              <div key={idx} className="rounded-md bg-primary/10 px-2 py-1">
                <div className="opacity-80">{item.label}</div>
                <div className="font-medium truncate">{item.value}</div>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  )
}
