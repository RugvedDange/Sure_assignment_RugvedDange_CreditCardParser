"use client"

// Helpful getters to normalize keys
function firstDefined(obj: Record<string, any>, keys: string[]) {
  for (const k of keys) {
    const found = Object.keys(obj).find((ok) => ok.toLowerCase() === k.toLowerCase())
    if (found && obj[found]) return obj[found]
  }
  return null
}

export function CreditCardDisplay({ data }: { data: Record<string, string | null> }) {
  // Pull canonical fields if present
  const name = firstDefined(data, ["Name", "Cardholder", "Card Holder", "Customer Name"]) ?? ""
  const last4 = firstDefined(data, ["Card Last 4 Digits", "Last4", "Last 4", "XXXX"]) ?? ""
  const totalDue = firstDefined(data, ["Total Dues", "Total Amount Due", "Total Due"]) ?? ""
  const minDue = firstDefined(data, ["Minimum Amount Due", "Min Amount Due", "Minimum Due"]) ?? ""
  const dueDate = firstDefined(data, ["Payment Due Date", "Due Date"]) ?? ""
  const statementDate = firstDefined(data, ["Statement Date"]) ?? ""
  const creditLimit = firstDefined(data, ["Credit Limit"]) ?? ""
  const availableLimit = firstDefined(data, ["Available Credit Limit"]) ?? ""
  const email = firstDefined(data, ["Email"]) ?? ""

  // Build extras: anything not in the known set
  const known = new Set([
    "Name",
    "Cardholder",
    "Card Holder",
    "Customer Name",
    "Card Last 4 Digits",
    "Last4",
    "Last 4",
    "XXXX",
    "Total Dues",
    "Total Amount Due",
    "Total Due",
    "Minimum Amount Due",
    "Min Amount Due",
    "Minimum Due",
    "Payment Due Date",
    "Due Date",
    "Statement Date",
    "Credit Limit",
    "Available Credit Limit",
    "Email",
    "File Name",
  ])

  const extras = Object.entries(data)
    .filter(([k, v]) => v && !known.has(k))
    .slice(0, 6) // keep it compact on the card

  return (
    <div
      className="w-full max-w-md rounded-xl p-5"
      style={{
        background: "var(--card)",
        border: "1px solid var(--border)",
      }}
      aria-label="Credit card preview"
    >
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs opacity-80">Cardholder</div>
          <div className="text-lg font-semibold">{name || "—"}</div>
        </div>
        <div className="text-right">
          <div className="text-xs opacity-80">Statement</div>
          <div className="text-sm">{statementDate || "—"}</div>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <div>
          <div className="text-xs opacity-80">Last 4</div>
          <div className="text-base font-medium">{last4 ? `•••• ${last4}` : "—"}</div>
        </div>
        <div>
          <div className="text-xs opacity-80">Email</div>
          <div className="text-base">{email || "—"}</div>
        </div>
        <div>
          <div className="text-xs opacity-80">Total Due</div>
          <div className="text-base font-semibold">{totalDue || "—"}</div>
        </div>
        <div>
          <div className="text-xs opacity-80">Minimum Due</div>
          <div className="text-base">{minDue || "—"}</div>
        </div>
        <div>
          <div className="text-xs opacity-80">Due Date</div>
          <div className="text-base">{dueDate || "—"}</div>
        </div>
        <div>
          <div className="text-xs opacity-80">Credit Limit</div>
          <div className="text-base">{creditLimit || "—"}</div>
        </div>
        <div>
          <div className="text-xs opacity-80">Available Limit</div>
          <div className="text-base">{availableLimit || "—"}</div>
        </div>
      </div>

      {extras.length > 0 && (
        <div className="mt-4">
          <div className="text-xs opacity-80 mb-1">More</div>
          <ul className="text-sm grid grid-cols-2 gap-2">
            {extras.map(([k, v]) => (
              <li key={k} className="truncate">
                <span className="opacity-70">{k}:</span> <span>{v}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
