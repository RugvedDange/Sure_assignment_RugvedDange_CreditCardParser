"use client"

export type CardFieldMapping = {
  name?: string
  number?: string
  expiry?: string
  expiryMonth?: string
  expiryYear?: string
  cvv?: string
}

export default function FieldMapper({
  headers,
  mapping,
  onChange,
}: {
  headers: string[]
  mapping: CardFieldMapping
  onChange: (m: CardFieldMapping) => void
}) {
  const options = (
    <>
      <option value="">— Not set —</option>
      {headers.map((h) => (
        <option key={h} value={h}>
          {h}
        </option>
      ))}
    </>
  )

  return (
    <div className="grid gap-3">
      <div className="grid gap-1.5">
        <label htmlFor="name" className="text-sm">
          Cardholder Name
        </label>
        <select
          id="name"
          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={mapping.name || ""}
          onChange={(e) => onChange({ ...mapping, name: e.target.value })}
        >
          {options}
        </select>
      </div>

      <div className="grid gap-1.5">
        <label htmlFor="number" className="text-sm">
          Card Number
        </label>
        <select
          id="number"
          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={mapping.number || ""}
          onChange={(e) => onChange({ ...mapping, number: e.target.value })}
        >
          {options}
        </select>
      </div>

      <div className="grid gap-1.5">
        <label htmlFor="expiry" className="text-sm">
          Expiry (Single Column)
        </label>
        <select
          id="expiry"
          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={mapping.expiry || ""}
          onChange={(e) => onChange({ ...mapping, expiry: e.target.value })}
        >
          {options}
        </select>
        <p className="text-xs text-muted-foreground">
          If your CSV has separate month/year columns, leave this unset and map them below.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="grid gap-1.5">
          <label htmlFor="expiryMonth" className="text-sm">
            Expiry Month
          </label>
          <select
            id="expiryMonth"
            className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
            value={mapping.expiryMonth || ""}
            onChange={(e) => onChange({ ...mapping, expiryMonth: e.target.value })}
          >
            {options}
          </select>
        </div>
        <div className="grid gap-1.5">
          <label htmlFor="expiryYear" className="text-sm">
            Expiry Year
          </label>
          <select
            id="expiryYear"
            className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
            value={mapping.expiryYear || ""}
            onChange={(e) => onChange({ ...mapping, expiryYear: e.target.value })}
          >
            {options}
          </select>
        </div>
      </div>

      <div className="grid gap-1.5">
        <label htmlFor="cvv" className="text-sm">
          CVV/CVC
        </label>
        <select
          id="cvv"
          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={mapping.cvv || ""}
          onChange={(e) => onChange({ ...mapping, cvv: e.target.value })}
        >
          {options}
        </select>
      </div>
    </div>
  )
}
