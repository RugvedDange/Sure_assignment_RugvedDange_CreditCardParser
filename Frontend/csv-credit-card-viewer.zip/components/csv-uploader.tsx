"use client"

import { useState } from "react"
import Papa from "papaparse"

type Row = Record<string, string>

export default function CSVUploader({
  onParsed,
}: {
  onParsed: (headers: string[], rows: Row[]) => void
}) {
  const [error, setError] = useState<string>("")
  const [fileName, setFileName] = useState<string>("")

  function handleFile(file: File) {
    setError("")
    setFileName(file.name)
    Papa.parse<Row>(file, {
      header: true,
      skipEmptyLines: "greedy",
      transformHeader: (h) => h.trim(),
      complete: (results) => {
        const rows = (results.data || []).filter(Boolean)
        const headers = (results.meta.fields || []).filter(Boolean) as string[]
        if (!headers.length || !rows.length) {
          setError("No rows or headers found in the CSV.")
          return
        }
        onParsed(headers, rows)
      },
      error: (err) => {
        setError(`Failed to parse CSV: ${err.message}`)
      },
    })
  }

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-medium">Upload CSV</h2>
          <p className="text-xs text-muted-foreground">Accepted format: .csv with header row</p>
        </div>
        <label className="inline-flex cursor-pointer items-center rounded-md bg-primary px-3 py-2 text-sm text-primary-foreground hover:opacity-90">
          <input
            type="file"
            accept=".csv,text/csv"
            className="sr-only"
            onChange={(e) => {
              const f = e.target.files?.[0]
              if (f) handleFile(f)
            }}
          />
          Choose file
        </label>
      </div>

      <div className="mt-3 text-sm">
        <span className="text-muted-foreground">Selected:</span> <span>{fileName || "No file selected"}</span>
      </div>

      <div role="status" aria-live="polite" className="mt-2 text-xs text-destructive-foreground">
        {error}
      </div>
    </div>
  )
}
