"use client"

export default function ReadOnlyCardForm({
  name,
  number,
  expiry,
  cvv,
}: {
  name: string
  number: string
  expiry: string
  cvv: string
}) {
  const inputClass = "w-full rounded-md border border-input bg-background px-3 py-2 text-sm"

  return (
    <form className="grid gap-3" onSubmit={(e) => e.preventDefault()}>
      <div className="grid gap-1.5">
        <label htmlFor="cc-number" className="text-sm">
          Card Number
        </label>
        <input id="cc-number" className={inputClass} value={number} readOnly />
      </div>

      <div className="grid gap-1.5">
        <label htmlFor="cc-name" className="text-sm">
          Cardholder Name
        </label>
        <input id="cc-name" className={inputClass} value={name} readOnly />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="grid gap-1.5">
          <label htmlFor="cc-expiry" className="text-sm">
            Expiry (MM/YY)
          </label>
          <input id="cc-expiry" className={inputClass} value={expiry} readOnly />
        </div>
        <div className="grid gap-1.5">
          <label htmlFor="cc-cvv" className="text-sm">
            CVV
          </label>
          <input id="cc-cvv" className={inputClass} value={cvv} readOnly />
        </div>
      </div>
    </form>
  )
}
